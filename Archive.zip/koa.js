//IMPORT MODULES
require('marko/node-require');
const Koa = require('koa');
const Router = require('koa-router');

const app = new Koa();
const router = new Router();



//CONFIGURE ROUTER


router.get('/',(ctx,next)=>{
	const home_page= require('./templates/home.marko');
	ctx.type='html';
	ctx.body=home_page.stream();
	next();
});
router.get('/electricity',(ctx,next)=>{
	const electricity_page= require('./templates/electricity.marko');
	ctx.type='html';
	ctx.body=electricity_page.stream();
	next();

});
router.get('/gas',(ctx,next)=>{
	const gas_page= require('./templates/gas.marko');
	ctx.type='html';
	ctx.body=gas_page.stream();
	next();

});
//END CONFIGURE ROUTER


//Middleware
app.use(router.routes())
app.use(router.allowedMethods())

/*app.use(async (ctx,next) => {     // context (req,res --> toghether)
 	ctx.body += '<h1>Hello World</h1>  <p>KOA.JS</p>';
  	next();
});*/

//END middleware



//START SERVER
app.listen(3000);