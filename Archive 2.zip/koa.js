//IMPORT MODULES
require('marko/node-require');
const Koa = require('koa');
const Router = require('koa-router');
const serve = require('koa-static');  // install koa-static
const k_body = require('koa-body') // install koa-body

const app = new Koa();
const router = new Router();



//CONFIGURE ROUTER


router.get('/',(ctx,next)=>{
	const home_page= require('./templates/pages/home.marko');
	ctx.type='html';
	ctx.body=home_page.stream();
	next();
});

router.get('/electricity',(ctx,next)=>{
	const electricity_page= require('./templates/pages/electricity.marko');
	ctx.type='html';
	ctx.body=electricity_page.stream();
	next();

});
router.post('/electricity',(ctx,next)=>{
	var last= ctx.request.body.last_index;
	var curr= ctx.request.body.current_index;
	var amount = (curr - last) * 1.5;

	
	ctx.body = "You have to pay "+amount +" lei";
})

router.get('/gas',(ctx,next)=>{
	const gas_page= require('./templates/pages/gas.marko');
	ctx.type='html';
	ctx.body=gas_page.stream();
	next();

});
//END CONFIGURE ROUTER


//Middleware
app.use(k_body());
app.use(router.routes())
app.use(router.allowedMethods())
app.use(serve('./public')); // use all from public

//END middleware



//START SERVER
console.log("SERVER RUNNING IN DEVELOPMENT", process.ENV != 'production' );
console.log('SERVER app running in ', process.cwd());
app.listen(3000);